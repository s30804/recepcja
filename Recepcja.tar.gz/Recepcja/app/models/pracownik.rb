class Pracownik < ApplicationRecord
end
