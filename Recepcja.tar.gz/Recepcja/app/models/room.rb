class Room < ApplicationRecord
belongs_to :klient
end
