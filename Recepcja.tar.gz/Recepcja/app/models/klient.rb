class Klient < ApplicationRecord
has_many :room
end
