require 'test_helper'

class KlientTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
