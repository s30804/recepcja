class AddKlientRefToRoom < ActiveRecord::Migration[5.0]
  def change
    add_column :rooms, :Room, :string
    add_reference :rooms, :klient, foreign_key: true
  end
end
