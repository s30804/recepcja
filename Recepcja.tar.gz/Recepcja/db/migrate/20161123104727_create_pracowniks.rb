class CreatePracowniks < ActiveRecord::Migration[5.0]
  def change
    create_table :pracowniks do |t|
      t.string :imie
      t.string :nazwisko

      t.timestamps
    end
  end
end
