class CreateKlients < ActiveRecord::Migration[5.0]
  def change
    create_table :klients do |t|
      t.string :imie
      t.string :nazwisko
      t.string :miejscowosc
      t.string :adres
      t.integer :telefon
      t.integer :wiek

      t.timestamps
    end
  end
end
